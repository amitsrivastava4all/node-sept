const os = require('os');
console.log('Platform ' , os.platform());
console.log('Arch ', os.arch());
console.log('Home Dir ', os.homedir());
console.log('Network Interfaces ',os.networkInterfaces())
console.log('Core ', os.cpus().length)
console.log(os.freemem());
console.log(os.totalmem());
console.log(os.version());