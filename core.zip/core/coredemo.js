console.log('Module Exports ' ,module.exports); // {}
console.log('Require ', require);
console.log('Argv ', process.argv);
console.log('Buffer ', Buffer);
console.log('Current Dir Path ', __dirname);
console.log('Current FilePath ', __filename);
console.log('Global ', global);
console.log('SetTimeout ', setTimeout);
console.log('Set Interval ',setInterval);