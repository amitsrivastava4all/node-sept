const fs = require('fs'); // file system
const path = require('path');
const fullPath = path.join(__dirname,'myfile.txt');

// fs.watchFile(fullPath, (curr, prev)=>{
//     console.log('File Change ');
// })
fs.watch(__dirname,{recursive:true},(typeOfEvent, fileName)=>{
    console.log('Event ', typeOfEvent, 'File Name ', fileName);
})

// fs.appendFile(fullPath, 'Another Data', (err)=>{
//     if(err){
//         console.log('Unable to Append in a file' , err);
//     }
//     else{
//         console.log('Append It');
//     }
// })
// fs.copyFile(sourcePath, desPath, (err)=>{

// })
// fs.unlink(fullPath,(err)=>{

// })
// fs.rename(oldPath, newPath, err=>{

// })
//console.log(fs.existsSync(__dirname+"/a")?"Exist":"Not Exist");

// fs.mkdir(__dirname+"/a/b",err=>{
//     if(err){
//         console.log('Unable to create dir');
//     }
//     else{
//         console.log('Dir Created...');
//     }
// })
// const p ='/Users/amitsrivastava/Documents/test/big-file.mp4';
// const p2 ='/Users/amitsrivastava/Documents/test/big-file-copy.mp4';
// const stream = fs.createReadStream(p);
// const wstream = fs.createWriteStream(p2);
// stream.pipe(wstream).on('finish', ()=>console.log('Copy Done...'));
// console.log('data write...');
// stream.on('data', chunk=>{
//     wstream.write(chunk);
//     console.log('Chunk is ' , chunk);
// })
// stream.on('end',()=>{
//     console.log('Copy Ends');
// })

// readFile - good for small files
// fs.readFile(__filename, (err, buffer)=>{
//     if(err){
//         console.log('Error ', err);
//     }
//     else{
//         console.log(buffer.toString());
//     }
// })
// const path = require('path');
// const fullPath = path.join(__dirname,'myfile.txt');
// fs.writeFile(fullPath,"Hello Node JS ",(err)=>{
//     if(err){
//         console.log('Unable to write in a file ', err);
//     }
//     else{
//         console.log('Done...');
//     }
// })