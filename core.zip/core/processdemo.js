//console.log(process);
process.on('uncaughtException', (err)=>{
    console.log('Error is ', err);
})
console.log('Node Version ', process.version);
//throw new Error('Some Error ......');
console.log('Libuv Version ',process.versions.uv);
console.log('Arch ', process.arch);
process.on('exit',(code)=>{
    console.log('Process Exit...', code);
})
//console.log('Arguments ',process.argv[2]);
const val = process.argv[2];
const port = process.argv[3];
if(val =='dev'){
    console.log('Application Running in Dev Mode ', port);
}
else if(val =='qct'){
    console.log('Running in Testing Mode ', port);
}
else if(val =='prod'){
    console.log('Running in Prod mode ', port);
}
else{
    console.log('Invalid Mode');
}
process.stdout.write('Hello Node JS\n'); // console.log
