console.log(module.exports);
console.log(exports);
console.log(module.exports === exports);
exports = {
    show(){
        console.log("I am show");
    },
    disp(){
        console.log("I am Disp");
    }
}
module.exports = exports;