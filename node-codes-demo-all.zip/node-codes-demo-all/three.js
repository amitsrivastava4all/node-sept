// function(exports, require,module, __filename , __dirname){
//  // Node Wrapper Fn
// }
var x = 10;
console.log(arguments);