function compute(a,b){
    return a + b;
}
console.log(module.exports);
module.exports = compute;