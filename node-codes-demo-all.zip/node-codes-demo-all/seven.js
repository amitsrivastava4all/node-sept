module.exports.a=10;
module.exports.b = 20;
module.exports.disp = function(){
    console.log("I am the Disp Fn");
}