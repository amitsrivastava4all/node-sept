import {add} from './a.js';
import chalk from 'chalk';
console.log(chalk.green.bold(add(10,20)));