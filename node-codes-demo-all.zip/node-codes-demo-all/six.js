const fn = require('./five');
//const obj = require('./seven');
const {a,b,disp} = require('./seven');
console.log(fn(100,200));
// console.log(obj.a);
// console.log(obj.b);
// obj.disp();
console.log(a,b);
disp();