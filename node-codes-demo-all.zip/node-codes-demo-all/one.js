console.log("Hello Node JS");
function show(a=0, b=0){
    return a + b;
}
console.log(show(10,20));