const fs = require('fs');
console.log("I am Sync Line ", __filename);
function callBackFn(error, buffer){
    if(error){
        console.log('Error During File Content Read ', error);
    }
    else{
        console.log('Data Comes ', buffer.toString());
    }
}
fs.readFile(__filename, callBackFn); // Async (Non Blocking)
console.log("I am the Another Sync Line");