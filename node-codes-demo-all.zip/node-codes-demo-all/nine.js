const obj = require('./eight');
console.log('Obj is ', obj);
obj.show();
obj.disp();